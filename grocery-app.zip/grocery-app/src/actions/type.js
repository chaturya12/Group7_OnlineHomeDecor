export const GET_ERRORS = "GET_ERRORS";
export const GET_PRODUCTS = "GET_PRODUCTS";
export const GET_PRODUCT = "GET_PRODUCT";
export const DELETE_PRODUCT="DELETE_PRODUCT";