import React from 'react';
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from 'axios';
import { createProduct } from '../../actions/ProductActions';
class AddProduct extends React.Component{
    constructor(props){
        super(props);
        this.state={
            productName:"",
            price:"",
            quantity:"",
            categoryName:""
            
            
        }
       
        this.onChange=this.onChange.bind(this);
    }
    componentWillReceiveProps(nextProps) {
        console.log("--------componentWillReceiveProps : Called----------");
        if (nextProps.errors) {
          this.setState({ errors: nextProps.errors });
        }
      }
        onChange(event){   
            console.log('---onchange---')         
           this.setState(
               {[event.target.name]:event.target.value}
           );
        }
        onSubmit=(event)=>{
            event.preventDefault();
            const newProduct = {
                productName:this.state.productName,
                price:this.state.price,
                quantity:this.state.quantity,
                categoryName:this.state.categoryName
            }
            console.log(newProduct);
            //  this.props.createProduct(newProduct,this.props.history);
    axios.post("http://localhost:8080/api/v2/Products",newProduct).then(c=>this.setState({prod:c.data}));
    alert("Product added succcesfully");
    this.props.history.push(`/dashboard`);
        }
        cancel(){
            this.props.history.push(`/dashboard`);
        }
    render(){
        return(
            <div>

                 <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">                                
                                <div className = "card-body">
                                <center>
                                    <form onSubmit={this.onSubmit}>                                       
                                        <h3 className="text-center">Add Product</h3>
                                         <div className = "form-group">
                                            <label>Product Name </label>
                                            <input placeholder="Product name"
                                            id="productName"
                                            name="productName"                                            
                                             className="form-control" 
                                            
                                             value={this.state.productName}
                                             onChange={this.onChange}
                                             required />
                                        </div>
                                        <div class="form-group">
                                        <label >Choose an Image</label>
                                        <input type="file"
                                         class="form-control-file"/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Price</label>
                                            <input  placeholder="Price"
                                            name="price"                                            
                                             pattern="[0-9]+" 
                                             className="form-control"
                                             value={this.state.price} 
                                             onChange={this.onChange}                                                                             
                                             required/>                                              
                                        </div>
                                        <div className = "form-group">
                                            <label>Quantity </label>
                                            <input 
                                            name="quantity"
                                             placeholder="Quantity"                                             
                                              className="form-control"
                                              value={this.state.quantity}
                                              onChange={this.onChange}                                             
                                                />
                                        </div>
                                        <div className = "form-group">
                                            <label>Product Category </label>
                                            <input  placeholder="Category"  
                                            name="categoryName"                                          
                                             className="form-control"       
                                             value={this.state.categoryName}  
                                             onChange={this.onChange}                                                                             
                                             required/>  
                                            </div>
                                        
                                        <button className="btn btn-success" >Add</button>                                                                         
                                        <button className="btn btn-danger"onClick={this.cancel.bind(this)}>Cancel</button>
                                      
                                    </form>
                                    </center>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
                                    </div>
        );
    }
}
AddProduct.propTypes = {
    createProduct:PropTypes.func.isRequired,
     errors:PropTypes.object.isRequired,
    

}
const mapStateToProps = state => ({
    errors: state.errors,
    // categories:state.categories
  });
export default connect(mapStateToProps,{createProduct})(AddProduct);